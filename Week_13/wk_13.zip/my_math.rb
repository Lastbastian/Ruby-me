module MyMath
  PI_CONST = 3.14159265358979323846

  def print_pi
    puts "Pi to 20 digits: " + PI_CONST.to_s
  end
end