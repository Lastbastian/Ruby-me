#!/usr/local/bin/ruby
# Name: Chris Bastian
# Crs : CS 132A
# Sect: 831
# File: myscript.rb
# Desc: My first ruby script.
100.downto(0) do |t|
  puts "#{t}!" # by convention indentation is 2 spaces
end
print 'Blast off!'
