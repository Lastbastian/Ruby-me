test = [0,1,2]

begin
  # puts [1, 2, 3].first(4, 5)
  # puts test.fetch(4)
  # puts foo
  # puts "hello".weird_method
  # puts 1/0

  rescue ArgumentError => e
    puts "Exception: " + e.message
    puts e.backtrace.join("<br>\n")
    puts "Argument Error"
  rescue IndexError => e
    puts "Exception: " + e.message
    puts e.backtrace.join("<br>\n")
    puts "Index Error"
  rescue NameError => e
    puts "Exception: " + e.message
    puts e.backtrace.join("<br>\n")
    puts "Name error"
  rescue NoMethodError => e
    puts "Exception: " + e.message
    puts e.backtrace.join("<br>\n")
    puts "This method is undefined"
  rescue ZeroDivisionError => e
    puts "Exception: " + e.message
    puts  e.backtrace.join("<br>\n")
    puts "Cannot divide by zero"
end